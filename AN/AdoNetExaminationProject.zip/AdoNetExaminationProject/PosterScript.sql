﻿-------------------------
--Base
-------------------------
create database PosterNew
on primary
	(
	 name = PosterNew,
	 filename = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\PosterNew.mdf',
	 size = 16MB,
	 maxsize = 64MB,
	 filegrowth = 2MB
	)
log on
	(
	 name = PosterNewLog,
	 filename = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\PosterNewLog.ldf',
	 size = 4MB,
	 maxsize = 16MB,
	 filegrowth = 512KB
	)
collate Latin1_General_CI_AI
-------------------------
--Tables
-------------------------
use PosterNew
create table EventTypes
(
	Id int not null identity(1,1) primary key,
	Name_ nvarchar(20) not null unique
)
create table AgeLimits
(
	Id int not null identity(1,1) primary key,
	Age int not null
)
create table Events_
(
	Id int not null identity(1,1) primary key,
	Name_ nvarchar(20) not null,
	DateTime_ datetime not null default(getdate()),
	Country nvarchar(20) not null,
	City nvarchar(20) not null,
	Adress nvarchar(20) not null,
	EventTypeId int foreign key(EventTypeId) references EventTypes(Id) default(1),
	Description_ nvarchar(50) null,
	AgeLimitId int foreign key(AgeLimitId) references AgeLimits(Id) default(1),
	Tickets int not null,
	SoldTickets int not null
)
create table Tickets
(
	Id int not null identity(1,1) primary key,
	EventId int foreign key(EventId) references Events_(Id) default(1),
	Price money not null default(1)
)
create table Customers
(
	Id int not null identity(1,1) primary key,
	Name_ nvarchar(20) not null,
	Surname nvarchar(20) not null,
	Birthdate date not null default(getdate()),
	TicketId int foreign key(TicketId) references Tickets(Id) default(1)
)
create table Archive
(
	Id int not null identity(1,1) primary key,
	Name_ nvarchar(20) not null,
	DateTime_ datetime not null,
	Country nvarchar(20) not null,
	City nvarchar(20) not null,
	Adress nvarchar(20) not null,
	EventTypeId int not null,
	Description_ nvarchar(50) null,
	AgeLimitId int not null,
	Tickets int not null,
	SoldTickets int not null
)
------------------------------
--Stored Procedures for select
------------------------------
use PosterNew 
go
create procedure SelectEventType @eventTypeId int as
begin
	if(@eventTypeId = 0)
	begin
		select * from PosterNew.dbo.EventTypes
	end
	else
	begin
		select * from PosterNew.dbo.EventTypes where PosterNew.dbo.EventTypes.Id = @eventTypeId
	end
end
go
use PosterNew
go
create procedure SelectAgeLimit @ageLimitId int as
begin
	if(@ageLimitId = 0)
	begin
		select * from PosterNew.dbo.AgeLimits AL
	end
	else
	begin
		select * from PosterNew.dbo.AgeLimits AL where AL.Id = @ageLimitId
	end
end
go
use PosterNew
go
create procedure SelectEvent @eventId int as
begin
	if(@eventId = 0)
	begin
		select E.Id, E.Name_, E.DateTime_, E.Country, E.City, E.Adress, E.EventTypeId, ET.Name_ as Name_1, E.Description_, E.AgeLimitId, AL.Age, E.Tickets, E.SoldTickets
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET, PosterNew.dbo.AgeLimits AL
		where E.EventTypeId = ET.Id and E.AgeLimitId = AL.Id
	end
	else
	begin
		select E.Id, E.Name_, E.DateTime_, E.Country, E.City, E.Adress, E.EventTypeId, ET.Name_ as Name_1, E.Description_, E.AgeLimitId, AL.Age, E.Tickets, E.SoldTickets
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET, PosterNew.dbo.AgeLimits AL
		where E.Id = @eventId and E.EventTypeId = ET.Id and E.AgeLimitId = AL.Id
	end
end
go
use PosterNew
go
create procedure SelectTicket @ticketId int as
begin
	if(@ticketId = 0)
	begin
		select T.Id, T.EventId, E.Name_, T.Price
		from PosterNew.dbo.Tickets T, PosterNew.dbo.Events_ E
		where T.EventId = E.Id
	end
	else
	begin
		select T.Id, T.EventId, E.Name_, T.Price
		from PosterNew.dbo.Tickets T, PosterNew.dbo.Events_ E
		where T.Id = @ticketId and T.EventId = E.Id
	end
end
go
use PosterNew
go
create procedure SelectCustomer @customerId int as
begin
	if(@customerId = 0)
	begin
		select C.Id, C.Name_, C.Surname, C.Birthdate, C.TicketId, E.Name_ as Name_1
		from PosterNew.dbo.Customers C, PosterNew.dbo.Tickets T, PosterNew.dbo.Events_ E
		where C.TicketId = T.Id and T.EventId = E.Id
	end
	else
	begin
		select C.Id, C.Name_, C.Surname, C.Birthdate, C.TicketId, E.Name_ as Name_1
		from PosterNew.dbo.Customers C, PosterNew.dbo.Tickets T, PosterNew.dbo.Events_ E
		where C.Id = @customerId and C.TicketId = T.Id and T.EventId = E.Id
	end
end
go
use PosterNew
go
alter procedure SelectFromArchive @fromArchiveId int as
begin
	if(@fromArchiveId = 0)
	begin
		select E.Id, E.Name_, E.DateTime_, E.Country, E.City, E.Adress, E.EventTypeId, ET.Name_ as Name_1, E.Description_, E.AgeLimitId, AL.Age, E.Tickets, E.SoldTickets
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET, PosterNew.dbo.AgeLimits AL
		where E.EventTypeId = ET.Id and E.AgeLimitId = AL.Id
	end
	else
	begin
		select E.Id, E.Name_, E.DateTime_, E.Country, E.City, E.Adress, E.EventTypeId, ET.Name_ as Name_1, E.Description_, E.AgeLimitId, AL.Age, E.Tickets, E.SoldTickets
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET, PosterNew.dbo.AgeLimits AL
		where E.Id = @fromArchiveId and E.EventTypeId = ET.Id and E.AgeLimitId = AL.Id
	end
end
go
-------------------------------
--Stored Procedures for Insert
-------------------------------
use PosterNew
go
set ansi_nulls on
go
set quoted_identifier on
go
create procedure InsertEvent @name nvarchar(20), @dateTime DateTime, @country nvarchar(20), @city nvarchar(20), @adress nvarchar(20), @eventTypeId int, @description nvarchar(50), @ageLimitId int, 
@tickets int, @soldTickets int, @eventId int output as
begin
	set nocount on
	insert into dbo.Events_(Name_, DateTime_, Country, City, Adress, EventTypeId, Description_, AgeLimitId, Tickets, SoldTickets) values
	(@name, @dateTime, @country, @city, @adress, @eventTypeId, @description, @ageLimitId, @tickets, @soldTickets) 
	return scope_identity()
	set @eventId = scope_identity()
end
go
use PosterNew
go
set ansi_nulls on
go
set quoted_identifier on
go
create procedure InsertTicket @eventId int, @price money, @ticketId int output as
begin
	set nocount on
	insert into dbo.Tickets(EventId, Price) values
	(@eventId, @price)
	return scope_identity()
	set @ticketId = scope_identity()
end
go
use PosterNew
go
set ansi_nulls on
go
set quoted_identifier on
go
create procedure InsertCustomer @name nvarchar(20), @surname nvarchar(20), @birthdate date, @ticketId int, @customerId int output as
begin
	set nocount on
	insert into dbo.Customers(Name_, Surname, Birthdate, TicketId) values
	(@name, @surname, @birthdate, @ticketId)
	return scope_identity()
	set @customerId = scope_identity()
end
go
use PosterNew
go
set ansi_nulls on
go
set quoted_identifier on
go
create procedure InsertIntoArchive @name nvarchar(20), @dateTime DateTime, @country nvarchar(20), @city nvarchar(20), @adress nvarchar(20), @eventTypeId int, @description nvarchar(50), @ageLimitId int, 
@tickets int, @soldTickets int, @inArchiveId int output as
begin
	set nocount on
	insert into dbo.Archive(Name_, DateTime_, Country, City, Adress, EventTypeId, Description_, AgeLimitId, Tickets, SoldTickets) values
	(@name, @dateTime, @country, @city, @adress, @eventTypeId, @description, @ageLimitId, @tickets, @soldTickets) 
	return scope_identity()
	set @inArchiveId = scope_identity()
end
go
-------------------------------
--Stored Procedures for Update
-------------------------------
use PosterNew 
go
create procedure UpdateEvent @eventId int, @name nvarchar(20), @dateTime DateTime, @country nvarchar(20), @city nvarchar(20), @adress nvarchar(20), @eventTypeId int, @description nvarchar(50), @ageLimitId int, 
@tickets int, @soldTickets int as
begin
	update Events_
	set Name_ = @name, DateTime_ = @dateTime, Country = @country, City = @city, Adress = @adress, EventTypeId = @eventTypeId, Description_ = @description, AgeLimitId = @ageLimitId, Tickets = @tickets, SoldTickets = @soldTickets
	where Events_.Id = @eventId
end
go
use PosterNew 
go
create procedure UpdateTicket @ticketId int, @eventId int, @price money as
begin
	update Tickets
	set EventId = @eventId, Price = @price
	where Tickets.Id = @ticketId
end
go
use PosterNew 
go
create procedure UpdateCustomer @customerId int, @name nvarchar(20), @surname nvarchar(20), @birthdate date, @ticketId int as
begin
	update Customers
	set Name_ = @name, Surname = @surname, Birthdate = @birthdate, TicketId = @ticketId
	where Customers.Id = @customerId
end
go
-------------------------------
--Stored Procedures for Delete	
-------------------------------
use PosterNew
go
create procedure DeleteEvent @eventId int as
	delete from PosterNew.dbo.Events_ where PosterNew.dbo.Events_.Id = @eventId
go
use PosterNew
go
create procedure DeleteTicket @ticketId int as
	delete from PosterNew.dbo.Tickets where PosterNew.dbo.Tickets.Id = @ticketId
go
use PosterNew
go
create procedure DeleteCustomer @customerId int as
delete from PosterNew.dbo.Customers where PosterNew.dbo.Customers.Id = @customerId
go
-------------------------------
--Exam things	
-------------------------------

--1 Отобразите все актуальные события на конкретную дату. Дата указывается в качестве параметра
	use PosterNew
	go
	create procedure Procedure1 @datetime datetime as
		select E.Name_ 'Name'
		from PosterNew.dbo.Events_ E 
		where E.DateTime_ = @datetime
	go
--2 Отобразите все актуальные события из конкретной категории. Категория указывается в качестве параметра
	use PosterNew
	go
	create procedure Procedure2 @EventTypeId int as
		select E.Name_ 'Name'
		from PosterNew.dbo.EventTypes ET, PosterNew.dbo.Events_ E
		where ET.Id = @EventTypeId and E.EventTypeID = ET.Id
	go
--3 Отобразите все актуальные события со стопроцентной продажей билетов
	use PosterNew
	go
	create procedure Procedure3 as
		select *
		from PosterNew.dbo.Events_ E
		where E.SoldTickets = E.Tickets
		go
--4 Отобразите топ-3 самых популярных актуальных событий (по количеству приобретенных билетов)
	use PosterNew
	go
	create procedure Procedure4 as
		select top(3) *
		from PosterNew.dbo.Events_ E
		order by E.SoldTickets desc
	go
--5 Отобразите топ-3 самых популярных категорий событий (по количеству всех приобретенных билетов). Архив событий учитывается
	use PosterNew
	go
		create procedure Procedure5 as
		select top(3) ET.Name_
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET
		where E.EventTypeId = ET.Id
		order by E.SoldTickets desc
		select top(3) ET.Name_
		from PosterNew.dbo.Archive A, PosterNew.dbo.EventTypes ET
		where A.EventTypeId = ET.ID
		order by A.SoldTickets desc
	go
--6 Отобразите самое популярное событие в конкретном городе. Город указывается в качестве параметра
	use PosterNew
	go
		create procedure Procedure6 @city nvarchar(20) as
		select *
		from PosterNew.dbo.Events_ E
		where E.City = @city and E.SoldTickets = 
		(
			select max(E.SoldTickets)
			from PosterNew.dbo.Events_ E
			where E.City = @city
		)
	go
--7 Покажите информацию о самом активном клиенте (по количеству купленных билетов)
	use PosterNew
	go
	create view View1 as
		select top 1 C.Name_ + ' ' + C.Surname as 'Customer', C.Birthdate, E.SoldTickets as 'Tickets Sold'
		from PosterNew.dbo.Customers C, PosterNew.dbo.Events_ E, PosterNew.dbo.Tickets T
		where C.TicketId=T.Id and T.EventId = E.Id
		order by E.SoldTickets desc
	go
--8 Покажите информацию о самой непопулярной категории (по количеству событий). Архив событий учитывается.
	use PosterNew
	go
	create procedure Procedure8 as
		select top(3) ET.Name_
		from PosterNew.dbo.Events_ E, PosterNew.dbo.EventTypes ET
		where E.EventTypeId = ET.Id
		order by E.SoldTickets asc
		select top(3) ET.Name_
		from PosterNew.dbo.Archive A, PosterNew.dbo.EventTypes ET
		where A.EventTypeId = ET.Id
		order by A.SoldTickets asc
	go
--■ Отобразите топ-3 набирающих популярность событий (по количеству проданных билетов за 5 дней)
	use PosterNew
	go
	create procedure Procedure9 @start datetime, @end datetime as
		select top (3) E.Name_, E.SoldTickets, E.DateTime_
		from PosterNew.dbo.Events_ E
		where E.DateTime_ between @start and @end
	go
--■ Покажите все события, которые пройдут сегодня в указанное время. Время передаётся в качестве параметра
	use PosterNew
	go
	create procedure Procedure10 @datetime datetime as
		select *
		from PosterNew.dbo.Events_ E
		where E.DateTime_ = @datetime
	go
--■ Покажите название городов, в которых сегодня пройдут события
	use PosterNew
	go
	create procedure Procedure11 @datetime datetime as
		select E.City
		from PosterNew.dbo.Events_ E
		where E.DateTime_ = @datetime
	go
--■ При вставке нового клиента нужно проверять, нет ли его
--уже в базе данных. Если такой клиент есть, генерировать
--ошибку с описанием возникшей проблемы
	use PosterNew
	go
	create trigger Trigger1 on Customers for insert as
		begin
			if(exists(select I.Name_, I.Surname, I.Birthdate from inserted I))
			begin
				raiserror('The client already exists', 0, 1)
			end
			else
				print('The client was succesfuly inserted')
		end
	go
--■ При вставке нового события нужно проверять, нет ли его
--уже в базе данных. Если такое событие есть, генерировать
--ошибку с описанием возникшей проблемы
	use PosterNew
	go
	create trigger Trigger2 on Events_ for insert as
		begin
			if(exists(select I.Name_, I.DateTime_, I.Country, I.City, I.Adress,  I.EventTypeId, I.AgeLimitId, I.Tickets, I.SoldTickets from inserted I))
			begin
				raiserror('The event already exists', 0, 1)
			end
			else
				print('The event was succesfuly inserted')
		end
	go
--■ При удалении прошедших событий необходимо их переносить в архив событий
	use PosterNew
	go
	create trigger Trigger3 on Events_ after delete as
		insert PosterNew.dbo.Archive(Name_,DateTime_, Country, City, Adress, EventTypeId, Description_, AgeLimitId, Tickets, SoldTickets)
		select Name_, DateTime_, Country, City, Adress, EventTypeId, Description_, AgeLimitId, Tickets, SoldTickets from deleted
	go
--■ При попытке покупки билета проверять не достигнуто ли уже максимальное количество билетов. Если максимальное количество достигнуто, генерировать ошибку с информацией о возникшей проблеме
--■ При попытке покупки билета проверять возрастные ограничения. Если возрастное ограничение нарушено, генерировать ошибку с информацией о возникшей проблеме
	use PosterNew
	go
	create procedure SaleTicket @eventId int, @CustomerId int as
		declare @i int set @i = 0
		declare @tickets int set @tickets = (select PosterNew.dbo.Events_.Tickets from PosterNew.dbo.Events_ where PosterNew.dbo.Events_.Id = @eventId)
		declare @soldTickets int set @soldTickets = (select PosterNew.dbo.Events_.SoldTickets from PosterNew.dbo.Events_ where PosterNew.dbo.Events_.Id = @eventId)
		declare @agelimit int set @agelimit = (select PosterNew.dbo.AgeLimits.Age from PosterNew.dbo.AgeLimits, PosterNew.dbo.Events_ where PosterNew.dbo.Events_.Id = @eventId
		and PosterNew.dbo.Events_.AgeLimitId = PosterNew.dbo.AgeLimits.Id)
		declare @bd date set @bd = (select PosterNew.dbo.Customers.Birthdate from PosterNew.dbo.Customers where PosterNew.dbo.Customers.Id = @CustomerId)
		declare @age int set @age = (select year(GETDATE()) as year) - (select year(@bd) as year)
		if(@tickets = @soldTickets)
		begin
			raiserror('Error: all tickets were sold. . .',1,0)
			set @i = 1
		end
		if(@age < @ageLimit)
		begin
			raiserror('Error: not enough age. . .',1,0)
			set @i = 1
		end
		if(@i = 0)
			update PosterNew.dbo.Events_
			set PosterNew.dbo.Events_.SoldTickets = PosterNew.dbo.Events_.SoldTickets + 1
			from PosterNew.dbo.Events_ where PosterNew.dbo.Events_.Id = @eventId
			print('Another one ticket was sold...')
	go
--■ Настроить создание резервных копий с периодичностью раз в день