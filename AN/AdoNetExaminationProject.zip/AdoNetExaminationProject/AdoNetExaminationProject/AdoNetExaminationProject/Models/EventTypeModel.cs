﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNetExaminationProject.Models
{
    public class EventTypeModel
    {
        public int Id { get; set; }
        public string Name_ { get; set; }
    }
}
