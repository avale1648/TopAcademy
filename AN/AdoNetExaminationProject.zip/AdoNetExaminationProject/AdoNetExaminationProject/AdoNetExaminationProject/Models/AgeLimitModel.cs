﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdoNetExaminationProject.Models
{
    public class AgeLimitModel
    {
        public int Id { get; set; }
        public int Age { get; set; }
    }
}
